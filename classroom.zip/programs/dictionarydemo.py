book = {"chap1":10 ,"chap2":20,"chap3":30}
# add new key-value pair
book['chap4'] = 40
book['chap5'] = 50
print(book)
# display the individual value
print(book['chap1']) # 10
print(book['chap2']) # 20

## working with dict methods
print(book.keys())     # keys
print(book.values())   # values
print(book.items())    # list of tuples  ( key,value)
#print(book['chap9'])
print(book.get('chap1')) # if key exists.. it returns the value
                      # if key not existing.. it returns None
## check for existence
if 'chap9' in book:
    print(book['chap9'])
else:
    print("value doesnt exist")
    
# method1 :
newbook = {"chap6":60 ,"chap7":70}
# combining both the dictionaries
finalbook = {**book, **newbook}
print(finalbook)

# method2 for combibing two dictionaries
book.update(newbook)
print(book)

book.pop('chap1')
print('After pop operaiton :',book) # chap1:10 will be removed 

book.popitem()   # last key,value will be removed from dictionary
print(book)
book.popitem()
print(book)
book.popitem()
print(book)






