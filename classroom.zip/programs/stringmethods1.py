
name = 'python programming'
print(name)
print("I love",name)
# slicing
# string[start:stop:incremental]
print(name[0])
print(name[1])
print(name[0:3])  #pyt
print(name[3:9])  #hon pr
print(name[0:3:1])
print(name[0:18])
print(name[0:18:1])
print(name[:])
print(name[::])
print(name[0:18:2])
print(name[1:18:3])
print(name[-1])
print(name[-4:-1:1])
print(name[::-1])


name = 'python programming'
print(name.capitalize())
print(name.title())
print(name.upper())
print(name.lower())
print(name.center(40))
print(name.center(40,'*'))
print(name.count("p"))
print(name.count("z"))
print(name.endswith("g"))
print(name.endswith("m"))
print(name.startswith("p"))
print(name.startswith("z"))
print(name.find("prog"))  # 7 - starting index
print(name.find("per"))   # -1 : not existing

aname = "I love {} and {}"
print(aname.format("python","scala"))
print(aname.format("c","cpp"))

print(name.split(" "))

print(name.isalpha())
print(name.isalnum())
print(name.isnumeric())
print(name.isupper())
print(name.islower())

bname = "  python "
print(len(bname))
print(len(bname.strip()))  # will remove white spaces at bothemds
print(len(bname.lstrip())) # left side
print(len(bname.rstrip()))


print(name.replace("python","scala"))







