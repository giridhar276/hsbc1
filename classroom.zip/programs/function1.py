# fixed aguments
def add(a,b):         # fixed aguments
      c = a + b
      return c
total = add(10,20)    ## calling function
print(total)
###################################################
def add(a = 0,b= 0,c = 0):   #default arguments
    print(a,b,c)
add()
add(10)
add(10,20)
add(10,20,30)
###################################################
def add(b,a,c):    ## keyword aguments
    print(a,b,c)
add(a=10,b=20,c=30)
###################################################
def display(*data):  ## variable length arguments
    for val in data:
        print(val)
display(10,20,30,45,43,65,2,53,64,53,64,45,32,645,3)










