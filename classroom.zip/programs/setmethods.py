
aset = {10,10,20,30,30,40,40,20,20}

bset = {30,30,30,30,40,40,40,50}

aset.add(10)  # no changes in the aset
print(aset)
aset.add(60)

print(aset.union(bset))

print(aset.intersection(bset))

print(aset.difference(bset))

print(aset.issubset(bset))

print(aset.issuperset(bset))