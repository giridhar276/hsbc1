
# read the file using file object
# fr acts like an cursor or pointer or reference
with open("languages.txt","r") as fr:
    for line in fr:
        print(line.strip())
        
# fobj.read()
with open("languages.txt","r") as fr:
    print(fr.read())  # will return the string    
        
import csv
with open("languages.txt","r") as fr:
    # converts file object to the csv object
    data = csv.reader(fr)
    for line in data:
        print(line)