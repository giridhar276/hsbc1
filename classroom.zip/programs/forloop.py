# string iteration
name = 'python'
for char in name:
    print(char)
        
# iterating the list
alist = [10,20,30,40]
for val in alist:
    print(val)
    
# iterating the dictionary
book = {"chap1":10 ,"chap2":20}
# display all the keys line by line
for key in book:
    print(key)
    
for key in book.keys():
    print(key)
    
# display values
for value in book.values():
    print(value)
    
for key,value in book.items():
    print(key,value)
    
# set
data = {10,10,10,10,20,20,30,30,30}
for val in data:
    print(val)

