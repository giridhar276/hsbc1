


ip = input("Enter IP Address :")
iplist = ip.split(".")
if len(iplist) == 4:
    if int(iplist[0]) in range(1,255)  and  int(iplist[1]) in range(0,255) and int(iplist[2]) in range(0,255) and int(iplist[3]) in range(0,255) :
        print("Valid IP")
    else:
        print("Invalid ip")
else:
    print("Invalid IP")
