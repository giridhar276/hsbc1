#case1: if file is not existing,file gets created firstly
#case2: if file is already existing,it overwrites the existing content


fobj = open("languages.txt","w")
fobj.write('python programming\n')
fobj.write('unix shell\n')
fobj.write('java programming\n')
fobj.close()


fobj = open('numbers.txt','w')
for line in range(1,11):
    fobj.write(str(line) + "\n")
fobj.close()

#fobj = open('C:/Users/gsripath/Desktop/numbers.txt','w')
#fobj = open(r'C:\Users\gsripath\Desktop\numbers.txt','w') # raw string
fobj = open('C:\\Users\\gsripath\\Desktop\\numbers.txt','w')
for line in range(1,11):
    fobj.write(str(line) + "\n")
fobj.close()


# regular way # legacy way
fobj = open('abc.txt','w')
for line in range(1,11):
    fobj.write(str(line) + "\n")
fobj.close()

# pythonic way
### context manager
# if any line starts with keyword with .. we call it as context manager
# Advantage: file gets closed automatically when the pointer is
#             out of indentation
with open('abc.txt','w') as fw:
    for line in range(1,11):
        fw.write(str(line) + "\n")
    










