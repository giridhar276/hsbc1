alist = [10,23,76,10,64,30,19]
alist.append(59)
alist.append(30)
print('After appending:',alist)
alist.extend([93,59,18])
print('After extending :',alist)
alist.insert(1,100)
alist.insert(4,43)
print('AFter inserting :',alist)

alist.pop()  # last elements will be removed if index not passed
print('After pop :',alist)
alist.pop(2)  # 2 is the index
print('After pop :',alist)
alist.remove(10)  # 10 is the value
print(alist)

if 103 in alist:
    alist.remove(103)
    print(alist)
else:
    print("103 not in the list")

alist.reverse()
print('After reversing :',alist)
alist.sort()
print('After sorting :',alist)
alist.sort(reverse=True)
print('After sorting :',alist)


