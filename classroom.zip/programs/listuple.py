
# list
alist = [10,20,30,40]
alist[0] = 100
print(alist)

# tuple ( immutable)
atup = (30,40,50,60)
atup[0] = 300
print(atup)

# typcasting - converting from one object to another ob
# elements within the tuple cannot be modified directly
alist = list(atup) # converting to list
alist.append(50)   # making changes  to list
atup = tuple(alist) # reconverting back to tuple
print(atup)         # displaying tuple
