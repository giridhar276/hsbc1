
name = 'python programming'
print(name)
print("I love",name)
# slicing
# string[start:stop:incremental]
print(name[0])
print(name[1])
print(name[0:3])  #pyt
print(name[3:9])  #hon pr
print(name[0:3:1])
print(name[0:18])
print(name[0:18:1])
print(name[:])
print(name[::])
print(name[0:18:2])
print(name[1:18:3])
print(name[-1])
print(name[-4:-1:1])
print(name[::-1])


name = 'python programming'
print(name..










