
def add(a,b):         # fixed aguments
      c = a + b
      return c
total = add(10,20)    ## calling function
print(total)

# lambda function # nameless function
# lambda is the replacement of single liner function
# Advantage :  the function body gets replaced in the function call
# syntax
# function_name = lambda variables :expression

add = lambda x,y: x + y
total = add(10,20)    ## calling function
print(total)

convert = lambda x: int(x)
print(convert('10'))

square = lambda x : x * x  if x >0  else "not possbile"
print(square(20))



alist = ["google","facebook","java"]
# method1
blist =[]
for item in alist:
    blist.append("www." + item + ".com")
print(blist)    
# method2
name = "www.{}.com"
for item in alist:
    blist.append(name.format(item))
print(blist)  
# using list comprehension
alist = ["google","facebook","java"]
#list comprehension   [ expression forloop ]
blist = [ "www." + val + ".com"  for val in alist]
print(blist)

# using map(function,iterable)
def append(x):
    return "www." + x +".com"
# map(function,iterable)
print(list(map(append,alist)))


append = lambda x : "www." + x + ".com"
print(list(map(append,alist)))

print(list(map(lambda x : "www." + x + ".com",alist)))













#expected output :output
#["www.google.com","www.facebook.com","www.java.com"]







#########################################

numbers = ['1','2','3','4']

print(list(map(int,numbers)))


output = []
for val in numbers:
    output.append(int(val))




























