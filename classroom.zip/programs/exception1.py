try:
    filename = input('Enter any filename :')
    with open(filename,"r") as fr:
        for line in fr:
            print(line.strip())
except FileNotFoundError as e:
    print("system error :",e)
    print("file not found.. please check")
except TypeError as err:
    print("system error :",err)
except ValueError as err:
    print("system err :",err)
except (IndexError,KeyError) as err:
    print("system error:", err)
except Exception as err:
    print(err)
print("regualar code")
    
    
    